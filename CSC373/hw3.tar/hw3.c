/* CSC 373 Sections 601, 610 Spring 2018
   Implement each of the 5 functions below (1.5 each).
   They should all be in 1 file, called hw3.c -- there
   should NOT be a main function in your submission.

   Also submit the written portion of the assignment (2.5 points).
*/

int strcmp373(char str1[], char str2[]) {
	byte[] string1 = ASCIIEncoding.ASCII.GetBytes(str1);
	byte[] string2 = ASCIIEncoding.ASCII.GetBytes(str2);
	int index;
	while (string1[index] != string2[index]){
		index ++;
	}
	if (string1[index] < string2[index]){
		return string1[index] - string2[index]; 
	}
}

char *strcat373(char dest[], char src[]) {
  // add code here


  return dest; 
}

char *strchr37